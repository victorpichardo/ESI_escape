#ifndef PUZLES_H
#define PUZLES_H
#define MAX_PUZLES 50

#include "salas.h"

/**
 * @brief Estructura que almacena la informaci�n relativa a un desaf�o o puzle.
 */
typedef struct {
    char id_puzle[10];
    char nombre[50];
    char tipo[20];
    char pregunta[256];
    char solucion[50];
} Puzle;

/**
 * @brief Carga los datos de los puzles desde el fichero correspondiente al vector.
 * @pre El vector_puzles debe estar correctamente dimensionado con MAX_PUZLES.
 * @post Retorna el n�mero total de puzles cargados exitosamente.
 */
int cargar_puzles(Puzle vector_puzles[]);

/**
 * @brief Controla la interacci�n del jugador con los puzles en una sala espec�fica.
 * @pre Los vectores de conexiones y puzles deben estar inicializados y contener datos v�lidos.
 * @post Actualiza el estado de las conexiones si el puzle es resuelto correctamente.
 */
void gestionar_puzle(int id_sala, Conexion vector_conexiones[], int total_conexiones, Puzle vector_puzles[], int total_puzles);

#endif
