#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include "usuarios.h"

/**
 * @brief Vac�a el b�fer de entrada est�ndar (stdin).
 * @pre Ninguna.
 * @post El flujo de entrada queda libre de caracteres hasta encontrar un salto de l�nea o el fin del archivo.
 */
void limpiar_entrada() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

/**
 * @brief Gestiona la entrada de datos por teclado para dar de alta un nuevo usuario.
 * @pre El archivo "Jugadores.txt" debe tener permisos de escritura.
 * @post Se a�ade una nueva l�nea al archivo con los datos del usuario en formato delimitado por guiones.
 */
void crear_usuario() {
    Jugador nuevo;
    FILE *f = fopen("Jugadores.txt", "a+");
    if (!f) {
        printf("Error al abrir el archivo.\n");
        return;
    }

    /* Captura de datos mediante consola */
    printf("\n--- REGISTRO ---\n");
    printf("ID (2 digitos): ");
    scanf("%2s", nuevo.id);
    limpiar_entrada();

    printf("Nombre Completo: ");
    fgets(nuevo.nombre_completo, 21, stdin);
    nuevo.nombre_completo[strcspn(nuevo.nombre_completo, "\n")] = 0;

    printf("Username: ");
    scanf("%10s", nuevo.login);
    limpiar_entrada();

    printf("Password: ");
    scanf("%8s", nuevo.password);
    limpiar_entrada();

    /* Persistencia de la estructura en el fichero de texto */
    fprintf(f, "%s-%s-%s-%s-0\n", nuevo.id, nuevo.nombre_completo, nuevo.login, nuevo.password);
    fclose(f);
    printf("\n[OK] Usuario registrado.\n");
}

/**
 * @brief Compara las credenciales introducidas con las almacenadas en el sistema.
 * @pre El par�metro jugador_actual debe apuntar a una zona de memoria v�lida.
 * @post Retorna 1 si existe coincidencia de login y password, cargando los datos en la estructura; retorna 0 si no hay coincidencia.
 */
int autenticar_jugador(Jugador *jugador_actual) {
    char user_in[11], pass_in[9];
    FILE *f = fopen("Jugadores.txt", "r");
    if (!f) return 0;

    printf("\n--- LOGIN ---\nUsuario: ");
    scanf("%10s", user_in);
    limpiar_entrada();
    printf("Password: ");
    scanf("%8s", pass_in);
    limpiar_entrada();

    char linea[300];
    /* Lectura secuencial y troceado de cadenas mediante strtok */
    while (fgets(linea, sizeof(linea), f)) {
        char *id = strtok(linea, "-");
        char *nom = strtok(NULL, "-");
        char *log = strtok(NULL, "-");
        char *pas = strtok(NULL, "-");
        char *inv = strtok(NULL, "\n\r");

        /* Validaci�n de credenciales y volcado de datos si el login es correcto */
        if (log && pas && strcmp(user_in, log) == 0 && strcmp(pass_in, pas) == 0) {
            strcpy(jugador_actual->id, id);
            strcpy(jugador_actual->nombre_completo, nom);
            strcpy(jugador_actual->login, log);
            strcpy(jugador_actual->password, pas);
            strcpy(jugador_actual->inventario, (inv && strcmp(inv, "0") != 0) ? inv : "");
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    printf("\n[Error] Login incorrecto.\n");
    return 0;
}
