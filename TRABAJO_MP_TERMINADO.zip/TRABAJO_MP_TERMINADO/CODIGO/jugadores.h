#ifndef JUGADORES_H
#define JUGADORES_H

#include "usuarios.h"
#include "salas.h"

/**
 * @brief Visualiza de forma estructurada los objetos que posee el jugador actualmente.
 * @pre El puntero jugador debe apuntar a una sesi�n activa; el vector_objetos debe estar cargado.
 * @post Muestra por consola el nombre y descripci�n de cada objeto contenido en la cadena de inventario.
 */
void mostrar_inventario(Jugador *jugador, Objeto vector_objetos[], int total_objetos);

/**
 * @brief Sincroniza el estado del inventario del jugador con el almacenamiento persistente.
 * @pre La estructura jugador debe contener los datos actualizados del inventario en memoria.
 * @post Sobrescribe la informaci�n del usuario en el archivo de registros para reflejar los cambios.
 */
void guardar_inventario_usuario(Jugador jugador);

#endif
