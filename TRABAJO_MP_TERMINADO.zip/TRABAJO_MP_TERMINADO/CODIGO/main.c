#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "salas.h"
#include "ficheros.h"
#include "usuarios.h"
#include "puzles.h"
#include "jugadores.h"
#include "objetos.h"

/**
 * @brief Punto de entrada principal del programa.
 * @pre Los archivos de datos (.txt) y las dependencias de cabecera deben estar disponibles.
 * @post El programa finaliza su ejecuci�n devolviendo 0 tras gestionar la sesi�n y la partida.
 */
int main() {
    Jugador jugador_sesion;
    int sesion_iniciada = 0;

    /* Gesti�n del control de acceso al sistema */
    while (!sesion_iniciada) {
        printf("\n1. Iniciar Sesion\n2. Registrarse\n3. Salir\nSeleccione: ");
        int pre = getch() - '0';
        if (pre == 1) {
            if (autenticar_jugador(&jugador_sesion)) sesion_iniciada = 1;
        } else if (pre == 2) {
            crear_usuario();
        } else if (pre == 3) return 0;
    }

    /* Declaraci�n de estructuras de datos para el estado del juego */
    Sala mis_salas[MAX_SALAS];
    Conexion mis_conexiones[MAX_CONEXIONES];
    Objeto mis_objetos[MAX_OBJETOS];
    Puzle mis_puzles[MAX_PUZLES];

    int total_salas = cargar_salas(mis_salas);
    int total_conexiones = cargar_conexiones(mis_conexiones);
    int total_objetos = cargar_objetos(mis_objetos);
    int total_puzles = cargar_puzles(mis_puzles);

    int id_sala_actual = 1;

    while (1) {
        int opP = mostrarMenuPrincipal();
        if (opP == 3) break;

        if (opP == 1) {
            /* 1. Nueva Partida: Buscar la sala marcada como INICIAL */
            for(int i = 0; i < total_salas; i++) {
                if(strcmp(mis_salas[i].tipo, "INICIAL") == 0) {
                    id_sala_actual = mis_salas[i].id;
                    break;
                }
            }
            printf("\n--- COMENZANDO NUEVA AVENTURA ---\n");
        } else if (opP == 2) {
            if (!cargar_partida(jugador_sesion.id, &id_sala_actual, mis_objetos, total_objetos, mis_conexiones, total_conexiones)) {
                printf("\nNo hay partida guardada. Iniciando en sala por defecto...\n");
            }
        }

        int enPartida = 1;
        while (enPartida) {
            /* 2. Verificaci�n de condici�n de victoria (Sala tipo SALIDA) */
            if (strcmp(mis_salas[id_sala_actual - 1].tipo, "SALIDA") == 0) {
                describir_sala(mis_salas, total_salas, id_sala_actual);
                printf("\n**********************************************\n");
                printf("�ENHORABUENA! Has llegado a la salida. \n");
                printf("Felicidades %s, has completado el juego.\n", jugador_sesion.nombre_completo);
                printf("**********************************************\n");
                enPartida = 0;
                break;
            }

            int opJ = mostrarMenuPartida(mis_salas[id_sala_actual - 1].nombre);
            switch(opJ) {
                case 0: enPartida = 0; break;
                case 1: describir_sala(mis_salas, total_salas, id_sala_actual); break;
                case 2: examinar_sala(id_sala_actual, mis_objetos, total_objetos, mis_conexiones, total_conexiones); break;
                case 3: {
                    int destino = mostrar_destinos_posibles(id_sala_actual, mis_conexiones, total_conexiones);
                    if (destino != -1) entrar_sala(&id_sala_actual, destino, mis_conexiones, total_conexiones);
                    break;
                }
                case 4: coger_objeto(id_sala_actual, &jugador_sesion, mis_objetos, total_objetos); break;
                case 5: soltar_objeto(id_sala_actual, &jugador_sesion, mis_objetos, total_objetos); break;
                case 6: mostrar_inventario(&jugador_sesion, mis_objetos, total_objetos); break;
                case 7: usar_objeto(id_sala_actual, &jugador_sesion, mis_objetos, total_objetos, mis_conexiones, total_conexiones); break;
                case 8: gestionar_puzle(id_sala_actual, mis_conexiones, total_conexiones, mis_puzles, total_puzles); break;
                case 9: guardar_partida(jugador_sesion.id, id_sala_actual, mis_objetos, total_objetos, mis_conexiones, total_conexiones); break;
            }
        }
    }

    return 0;
}
