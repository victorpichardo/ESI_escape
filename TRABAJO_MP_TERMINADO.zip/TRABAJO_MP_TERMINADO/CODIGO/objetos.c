#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "objetos.h"
#include "jugadores.h"

/**
 * @brief Gestiona la transferencia de un objeto desde el entorno al inventario del jugador.
 * @pre El identificador id_sala debe ser v�lido; los vectores de objetos y jugador deben estar inicializados.
 * @post Modifica la localizaci�n del objeto a "Inventario" y actualiza la cadena de inventario del jugador si se confirma la selecci�n.
 */
void coger_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos) {
    int indices_disponibles[MAX_OBJETOS];
    int contador = 0;

    printf("\n--- OBJETOS EN ESTA SALA ---\n");
    for (int i = 0; i < total_objetos; i++) {
        if (atoi(vector_objetos[i].localizacion) == id_sala) {
            indices_disponibles[contador] = i;
            printf("%d. %s (%s)\n", contador + 1, vector_objetos[i].nombre, vector_objetos[i].id_obj);
            contador++;
        }
    }

    if (contador == 0) {
        printf("No hay objetos que puedas recoger aqu�.\n");
        return;
    }

    printf("0. Cancelar\n");
    printf("Selecciona el numero del objeto a recoger: ");

    int eleccion;
    if (scanf("%d", &eleccion) != 1) { while(getchar() != '\n'); return; }

    if (eleccion > 0 && eleccion <= contador) {
        int idx = indices_disponibles[eleccion - 1];

        if (strlen(jugador->inventario) > 0 && strcmp(jugador->inventario, "0") != 0) {
            strcat(jugador->inventario, ",");
        } else {
            strcpy(jugador->inventario, "");
        }
        strcat(jugador->inventario, vector_objetos[idx].id_obj);

        strcpy(vector_objetos[idx].localizacion, "Inventario");

        guardar_inventario_usuario(*jugador);
        printf("\n[OK] Has recogido: %s\n", vector_objetos[idx].nombre);
    } else {
        printf("\nAccion cancelada o seleccion no valida.\n");
    }
}

/**
 * @brief Permite al jugador depositar un objeto de su inventario en la sala actual.
 * @pre El inventario del jugador no debe estar vac�o.
 * @post Actualiza la localizaci�n del objeto con el ID de la sala y recompone la cadena del inventario del jugador.
 */
void soltar_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos) {
    if (strlen(jugador->inventario) == 0 || strcmp(jugador->inventario, "0") == 0) {
        printf("\nNo tienes nada en el inventario para soltar.\n");
        return;
    }

    char copia_inv[100];
    strcpy(copia_inv, jugador->inventario);

    char *ids_en_inventario[20];
    int contador = 0;

    printf("\n--- TU INVENTARIO ---\n");
    char *token = strtok(copia_inv, ",");
    while (token != NULL) {
        for (int i = 0; i < total_objetos; i++) {
            if (strcmp(vector_objetos[i].id_obj, token) == 0) {
                ids_en_inventario[contador] = vector_objetos[i].id_obj;
                printf("%d. %s\n", contador + 1, vector_objetos[i].nombre);
                contador++;
            }
        }
        token = strtok(NULL, ",");
    }

    printf("0. Cancelar\n");
    printf("�Que numero de objeto quieres soltar?: ");

    int eleccion;
    if (scanf("%d", &eleccion) != 1) { while(getchar() != '\n'); return; }

    if (eleccion > 0 && eleccion <= contador) {
        char *id_a_quitar = ids_en_inventario[eleccion - 1];
        char nuevo_inv[100] = "";

        char copia_para_borrar[100];
        strcpy(copia_para_borrar, jugador->inventario);
        char *t = strtok(copia_para_borrar, ",");

        int encontrado = 0;
        while (t != NULL) {
            if (strcmp(t, id_a_quitar) == 0 && !encontrado) {
                encontrado = 1;
            } else {
                if (strlen(nuevo_inv) > 0) strcat(nuevo_inv, ",");
                strcat(nuevo_inv, t);
            }
            t = strtok(NULL, ",");
        }

        if (strlen(nuevo_inv) == 0) strcpy(nuevo_inv, "0");
        strcpy(jugador->inventario, nuevo_inv);

        for (int i = 0; i < total_objetos; i++) {
            if (strcmp(vector_objetos[i].id_obj, id_a_quitar) == 0) {
                sprintf(vector_objetos[i].localizacion, "%02d", id_sala);
                printf("\n[OK] Has soltado %s en la sala.\n", vector_objetos[i].nombre);
                break;
            }
        }

        guardar_inventario_usuario(*jugador);
    } else {
        printf("\nAccion cancelada.\n");
    }
}

/**
 * @brief Eval�a y aplica el efecto de usar un objeto del inventario en la sala actual.
 * @pre El objeto debe existir en el inventario del jugador.
 * @post Si el objeto es el requerido por una conexi�n bloqueada, el estado de dicha conexi�n cambia a "Activa".
 */
void usar_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos, Conexion vector_conexiones[], int total_conexiones) {
    char id_obj[10];
    printf("\nQue objeto quieres usar? (Introduce su ID, puedes revisarlo en el inventario): ");
    scanf("%9s", id_obj);

    if (!strstr(jugador->inventario, id_obj)) {
        printf("No tienes ese objeto en tu inventario.\n");
        return;
    }

    for (int i = 0; i < total_conexiones; i++) {
        if (vector_conexiones[i].id_origen == id_sala &&
            strcmp(vector_conexiones[i].estado, "Bloqueada") == 0 &&
            strcmp(vector_conexiones[i].objeto_necesario, id_obj) == 0) {

            strcpy(vector_conexiones[i].estado, "Activa");
            printf("\n[EXITO] El objeto encaja! La salida hacia %s se ha abierto.\n", vector_conexiones[i].nombre_destino);
            return;
        }
    }
    printf("\nNo parece que puedas usar eso aqui ahora mismo.\n");
}
