#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "puzles.h"

/**
 * @brief Gestiona la identificaci�n y resoluci�n de puzles en la sala actual.
 * @pre id_sala debe ser v�lido; los vectores de datos deben estar inicializados y cargados.
 * @post Modifica el estado de las conexiones a "Activa" si la soluci�n es correcta.
 */
void gestionar_puzle(int id_sala, Conexion vector_conexiones[], int total_conexiones, Puzle vector_puzles[], int total_puzles) {
    int validos_con[10], validos_puz[10], contador = 0;

    /* Identificaci�n de puzles asociados a conexiones bloqueadas en la sala */
    printf("\n--- PUZLES Y PANELES EN ESTA SALA ---\n");
    for (int i = 0; i < total_conexiones; i++) {
        if (vector_conexiones[i].id_origen == id_sala && strcmp(vector_conexiones[i].estado, "Bloqueada") == 0) {
            for (int j = 0; j < total_puzles; j++) {
                if (strcmp(vector_conexiones[i].objeto_necesario, vector_puzles[j].id_puzle) == 0) {
                    validos_con[contador] = i;
                    validos_puz[contador] = j;
                    printf("%d. %s\n", contador + 1, vector_puzles[j].nombre);
                    contador++;
                }
            }
        }
    }

    if (contador == 0) {
        printf("No hay nada que resolver aqui.\n");
        return;
    }

    /* Selecci�n interactiva del puzle a resolver */
    printf("Elige panel (0 para volver): ");
    int sel;
    if (scanf("%d", &sel) != 1) { while(getchar() != '\n'); return; }
    while(getchar() != '\n');

    if (sel == 0) return;

    /* Verificaci�n de la respuesta introducida por el usuario */
    if (sel > 0 && sel <= contador) {
        int icon = validos_con[sel-1], ipuz = validos_puz[sel-1];
        char respuesta[50];
        printf("\n%s\n", vector_puzles[ipuz].pregunta);
        printf("Respuesta: ");
        fgets(respuesta, 50, stdin);
        respuesta[strcspn(respuesta, "\n\r")] = 0;

        if (strcmp(respuesta, vector_puzles[ipuz].solucion) == 0) {
            printf("\n[CORRECTO] Se ha escuchado un 'click'. El camino a %s ahora esta libre.\n", vector_conexiones[icon].nombre_destino);
            strcpy(vector_conexiones[icon].estado, "Activa");
        } else {
            printf("\n[ERROR] No parece ser la respuesta correcta.\n");
        }
    }
}
