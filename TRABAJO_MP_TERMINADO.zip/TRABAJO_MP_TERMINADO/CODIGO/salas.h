#ifndef SALAS_H
#define SALAS_H

/* Definici�n de constantes para el dimensionamiento de estructuras de datos */
#define MAX_SALAS 100
#define MAX_CONEXIONES 100
#define MAX_OBJETOS 100

/**
 * @brief Estructura que define las propiedades de una estancia del juego.
 */
typedef struct {
    int id;
    char nombre[50];
    char tipo[20];
    char descripcion[512];
} Sala;

/**
 * @brief Estructura que representa el enlace f�sico o l�gico entre dos salas.
 */
typedef struct {
    char id_conexion[10];
    int id_origen;
    char nombre_origen[50];
    int id_destino;
    char nombre_destino[50];
    char estado[20];
    char objeto_necesario[50];
} Conexion;

/**
 * @brief Estructura para la gesti�n de elementos interactuables en el entorno.
 */
typedef struct {
    char id_obj[10];
    char nombre[50];
    char descripcion[100];
    char localizacion[20];
} Objeto;

/* --- M�dulos de carga de datos persistentes --- */

/**
 * @brief Importa la informaci�n de las salas desde el fichero externo.
 * @pre El vector_salas debe tener capacidad para MAX_SALAS.
 * @post Retorna el n�mero total de salas cargadas correctamente.
 */
int cargar_salas(Sala vector_salas[]);

/**
 * @brief Importa la red de conexiones desde el almacenamiento secundario.
 * @pre El vector_conexiones debe estar correctamente dimensionado.
 * @post Retorna el n�mero total de conexiones le�das.
 */
int cargar_conexiones(Conexion vector_conexiones[]);

/**
 * @brief Carga la lista completa de objetos del juego.
 * @pre El vector_objetos debe estar inicializado en memoria.
 * @post Retorna la cantidad de objetos registrados.
 */
int cargar_objetos(Objeto vector_objetos[]);

/* --- M�dulos de l�gica y mec�nica de juego --- */

/**
 * @brief Muestra por pantalla la informaci�n detallada de una sala espec�fica.
 * @pre id_buscado debe ser un identificador v�lido dentro del rango de salas cargadas.
 * @post Se imprime la descripci�n de la sala por la salida est�ndar.
 */
void describir_sala(Sala vector_salas[], int total_salas, int id_buscado);

/**
 * @brief Lista los elementos y pasajes disponibles en la ubicaci�n actual.
 * @pre id_sala debe corresponder a la sala donde se encuentra el jugador.
 * @post Muestra por consola los objetos y estados de las conexiones adyacentes.
 */
void examinar_sala(int id_sala, Objeto vector_objetos[], int total_objetos, Conexion vector_conexiones[], int total_conexiones);

/**
 * @brief Gestiona el desplazamiento del jugador entre nodos del mapa.
 * @pre sala_actual debe ser un puntero a la variable de posici�n global.
 * @post Actualiza el valor de sala_actual si el tr�nsito es posible.
 */
void entrar_sala(int *sala_actual, int sala_destino, Conexion vector_conexiones[], int total_conexiones);

/**
 * @brief Identifica y presenta las salas adyacentes a la posici�n actual.
 * @pre id_sala_actual debe ser el ID de la ubicaci�n presente.
 * @post Retorna el ID del destino elegido o -1 si la operaci�n se cancela.
 */
int mostrar_destinos_posibles(int id_sala_actual, Conexion vector_conexiones[], int total_conexiones);

#endif
