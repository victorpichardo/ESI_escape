#ifndef USUARIOS_H
#define USUARIOS_H

#include "salas.h"

/* Definici�n de constantes para el control de l�mites del sistema */
#define MAX_JUGADORES 50

/**
 * @brief Estructura de datos para representar la entidad Jugador.
 * Contiene la informaci�n de perfil, credenciales de acceso y estado del inventario.
 */
typedef struct {
    char id[3];
    char nombre_completo[21];
    char login[11];
    char password[9];
    char inventario[100];
} Jugador;

/**
 * @brief Gestiona el acceso de un usuario al sistema mediante verificaci�n de credenciales.
 * @pre El par�metro jugador_actual debe ser un puntero v�lido a una estructura Jugador.
 * @post Devuelve 1 si la autenticaci�n es exitosa y carga los datos en la estructura; devuelve 0 en caso contrario.
 */
int autenticar_jugador(Jugador *jugador_actual);

/**
 * @brief Permite el registro de un nuevo usuario en el sistema.
 * @pre Ninguna. La funci�n gestiona la entrada de datos por teclado.
 * @post Crea una nueva entrada en el almacenamiento persistente de usuarios si los datos son v�lidos.
 */
void crear_usuario();

#endif
