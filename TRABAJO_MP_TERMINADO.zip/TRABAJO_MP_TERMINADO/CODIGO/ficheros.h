#ifndef FICHEROS_H
#define FICHEROS_H

#include "salas.h"
#include "puzles.h"

/** * --- SECCI�N: CARGA DE DATOS BASE ---
 * M�dulos encargados de la inicializaci�n del entorno de juego desde archivos de configuraci�n.
 */

/**
 * @brief Importa la definici�n de las salas desde el soporte f�sico.
 * @pre El vector_salas debe tener capacidad suficiente (MAX_SALAS).
 * @post Retorna el n�mero total de salas cargadas; inicializa el vector con los datos del fichero.
 */
int cargar_salas(Sala vector_salas[]);

/**
 * @brief Carga la red de adyacencia y estados de paso entre salas.
 * @pre El vector_conexiones debe estar correctamente dimensionado.
 * @post Retorna la cantidad de conexiones le�das y almacenadas en memoria.
 */
int cargar_conexiones(Conexion vector_conexiones[]);

/**
 * @brief Lee la lista de objetos interactuables y su ubicaci�n inicial.
 * @pre El vector_objetos debe estar inicializado en el �mbito de llamada.
 * @post Retorna el n�mero de objetos procesados con �xito.
 */
int cargar_objetos(Objeto vector_objetos[]);

/**
 * @brief Carga los desaf�os y acertijos l�gicos del juego.
 * @pre El vector_puzles debe estar disponible en memoria.
 * @post Retorna el total de puzles importados para su posterior gesti�n.
 */
int cargar_puzles(Puzle vector_puzles[]);


/** * --- SECCI�N: PERSISTENCIA INDIVIDUAL ---
 * Gesti�n del estado din�mico de la partida vinculado a un perfil de usuario �nico.
 */

/**
 * @brief Serializa el estado actual de la sesi�n en un archivo personalizado.
 * @pre id_jugador debe ser un identificador v�lido y los vectores deben contener el estado actual del mundo.
 * @post Crea o sobrescribe el archivo de salvaguarda espec�fico para el usuario.
 */
void guardar_partida(char* id_jugador, int id_sala, Objeto v_obj[], int t_obj, Conexion v_con[], int t_con);

/**
 * @brief Restaura el estado de una partida guardada previamente.
 * @pre Debe existir un archivo de partida vinculado al id_jugador.
 * @post Actualiza por referencia la sala actual y los estados de objetos/conexiones; retorna 1 si la carga es exitosa.
 */
int cargar_partida(char* id_jugador, int *id_sala, Objeto v_obj[], int t_obj, Conexion v_con[], int t_con);

#endif
