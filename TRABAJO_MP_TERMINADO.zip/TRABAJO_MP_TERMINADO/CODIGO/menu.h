#ifndef MENU_H
#define MENU_H

/**
 * @brief Presenta las opciones de gesti�n de partida al usuario.
 * @pre Ninguna.
 * @post Retorna el entero asociado a la opci�n elegida del men� principal.
 */
int mostrarMenuPrincipal();

/**
 * @brief Presenta las acciones disponibles dentro de la partida.
 * @pre nombreSala debe ser una cadena v�lida para la visualizaci�n contextual.
 * @post Retorna el c�digo de acci�n seleccionado por el jugador.
 */
int mostrarMenuPartida(char* nombreSala);

#endif
