#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "salas.h"

/**
 * @brief Busca y muestra la informaci�n textual de una sala espec�fica.
 * @pre El vector_salas debe estar cargado y total_salas debe ser mayor que 0.
 * @post Imprime por pantalla el tipo, nombre y descripci�n de la sala si el ID coincide.
 */
void describir_sala(Sala vector_salas[], int total_salas, int id_buscado) {
    for (int i = 0; i < total_salas; i++) {
        if (vector_salas[i].id == id_buscado) {
            printf("\n[%s] %s: %s\n", vector_salas[i].tipo, vector_salas[i].nombre, vector_salas[i].descripcion);
            return;
        }
    }
}

/**
 * @brief Lista los objetos presentes y las conexiones salientes de la ubicaci�n actual.
 * @pre id_sala debe ser un identificador v�lido; los vectores de objetos y conexiones deben estar inicializados.
 * @post Muestra por consola la relaci�n de elementos cuya localizaci�n o ID de origen coincida con la sala.
 */
void examinar_sala(int id_sala, Objeto vector_objetos[], int total_objetos, Conexion vector_conexiones[], int total_conexiones) {
    printf("\n--- EXAMINANDO SALA ---\n");
    for (int i = 0; i < total_objetos; i++) {
        if (atoi(vector_objetos[i].localizacion) == id_sala)
            printf("Objeto: %s - %s\n", vector_objetos[i].nombre, vector_objetos[i].descripcion);
    }
    for (int i = 0; i < total_conexiones; i++) {
        if (vector_conexiones[i].id_origen == id_sala)
            printf("Salida: %s [%s]\n", vector_conexiones[i].nombre_destino, vector_conexiones[i].estado);
    }
}

/**
 * @brief Realiza el cambio de ubicaci�n del jugador si la conexi�n lo permite.
 * @pre sala_actual debe ser un puntero a un entero; la conexi�n entre origen y destino debe existir.
 * @post Modifica el valor referenciado por sala_actual si el estado de la conexi�n es "Activa".
 */
void entrar_sala(int *sala_actual, int sala_destino, Conexion vector_conexiones[], int total_conexiones) {
    for (int i = 0; i < total_conexiones; i++) {
        if (vector_conexiones[i].id_origen == *sala_actual && vector_conexiones[i].id_destino == sala_destino) {
            if (strcmp(vector_conexiones[i].estado, "Activa") == 0) {
                *sala_actual = sala_destino;
                printf("\nHas avanzado a: %s\n", vector_conexiones[i].nombre_destino);
            } else {
                printf("\nAcceso bloqueado. Requiere: %s\n", vector_conexiones[i].objeto_necesario);
            }
            return;
        }
    }
}

/**
 * @brief Presenta un men� interactivo con las conexiones posibles desde la sala actual.
 * @pre total_conexiones debe reflejar el tama�o real del vector; id_sala_actual debe ser la posici�n vigente.
 * @post Devuelve el ID de la sala de destino seleccionada o -1 en caso de cancelaci�n o error.
 */
int mostrar_destinos_posibles(int id_sala_actual, Conexion vector_conexiones[], int total_conexiones) {
    int opciones[10], c = 0;
    printf("\n--- SALIDAS DISPONIBLES ---\n");
    for (int i = 0; i < total_conexiones; i++) {
        if (vector_conexiones[i].id_origen == id_sala_actual) {
            opciones[c] = vector_conexiones[i].id_destino;
            printf("%d. Ir a %s [%s]\n", c + 1, vector_conexiones[i].nombre_destino, vector_conexiones[i].estado);
            c++;
        }
    }
    if (c == 0) return -1;

    printf("Selecciona destino (0 para volver): ");
    int s;
    if (scanf("%d", &s) != 1) { while(getchar() != '\n'); return -1; }
    while(getchar() != '\n');
    if (s == 0) return -1;
    return (s > 0 && s <= c) ? opciones[s-1] : -1;
}
