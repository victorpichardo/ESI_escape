#include <stdio.h>
#include <conio.h>
#include "menu.h"

/**
 * @brief Despliega las opciones iniciales de gesti�n de partida en la interfaz de usuario.
 * @pre Ninguna.
 * @post Retorna un valor entero (1-3) correspondiente a la opci�n seleccionada por el usuario a trav�s de la entrada por teclado.
 */
int mostrarMenuPrincipal() {
    int tecla;
    printf("\n---- MENU PRINCIPAL ----\n");
    printf("1. New Game\n2. Load Game\n3. Salir\n");
    printf("Seleccione [1-3]: ");

    /* Bucle de control para asegurar una entrada v�lida dentro del rango definido */
    while (1) {
        tecla = getch();
        if (tecla >= '1' && tecla <= '3') {
            printf("%c\n", tecla);
            return tecla - '0';
        }
    }
}

/**
 * @brief Presenta el cat�logo de acciones disponibles para la interacci�n en el entorno de juego.
 * @pre El par�metro nombreSala debe ser un puntero a una cadena de caracteres que identifique la ubicaci�n actual.
 * @post Retorna el c�digo de operaci�n (0-9) seleccionado por el jugador para ser procesado por el controlador principal.
 */
int mostrarMenuPartida(char* nombreSala) {
    int tecla;
    printf("\nSala: %s\n", nombreSala);
    printf("1. Describir sala    2. Examinar         3. Entrar\n");
    printf("4. Coger objeto      5. Soltar objeto    6. Inventario\n");
    printf("7. Usar objeto       8. Puzle / codigo   9. Guardar\n");
    printf("0. Volver\n");
    printf("Seleccione accion: ");

    /* Captura de entrada orientada a eventos mediante getch */
    while (1) {
        tecla = getch();
        if (tecla >= '0' && tecla <= '9') {
            printf("%c\n", tecla);
            return tecla - '0';
        }
    }
}
