#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ficheros.h"

/**
 * @brief Carga la configuraci�n de las estancias desde el repositorio de datos.
 * @pre El archivo "Salas.txt" debe existir y seguir el formato de campos delimitados por guiones.
 * @post Puebla el vector_salas con los registros le�dos y retorna el n�mero total de salas procesadas.
 */
int cargar_salas(Sala vector_salas[]) {
    /* Apertura del flujo de lectura persistente */
    FILE *f = fopen("Salas.txt", "r");
    if (!f) return 0;

    char linea[600];
    int c = 0;

    /* Bucle de procesamiento secuencial de registros */
    while (fgets(linea, sizeof(linea), f) && c < MAX_SALAS) {

        /* Extracci�n y delimitaci�n de atributos estructurales */
        char *id = strtok(linea, "-");
        char *nom = strtok(NULL, "-");
        char *tip = strtok(NULL, "-");
        char *des = strtok(NULL, "\n\r");

        /* Mapeo de datos validados a la estructura local (memoria vol�til) */
        if (id && nom) {
            vector_salas[c].id = atoi(id);
            strcpy(vector_salas[c].nombre, nom);
            strcpy(vector_salas[c].tipo, tip);
            strcpy(vector_salas[c].descripcion, des);
            c++;
        }
    }
    fclose(f);
    return c;
}

/**
 * @brief Importa la red de conexiones y sus estados de accesibilidad iniciales.
 * @pre El archivo "Conexiones.txt" debe estar disponible para lectura en el directorio de ejecuci�n.
 * @post Inicializa el vector de conexiones permitiendo la navegaci�n l�gica entre salas.
 */
int cargar_conexiones(Conexion vector_conexiones[]) {
    /* Establecimiento de conexi�n con el repositorio de topolog�a */
    FILE *f = fopen("Conexiones.txt", "r");
    if (!f) return 0;

    char linea[600];
    int c = 0;

    /* Iteraci�n sobre la matriz de rutas disponibles */
    while (fgets(linea, sizeof(linea), f) && c < MAX_CONEXIONES) {

        /* Segmentaci�n de los par�metros de enlace topol�gico */
        char *id = strtok(linea, "-");
        char *ido = strtok(NULL, "-");
        char *nomo = strtok(NULL, "-");
        char *idd = strtok(NULL, "-");
        char *nomd = strtok(NULL, "-");
        char *est = strtok(NULL, "-");
        char *obj = strtok(NULL, "\n\r");

        /* Asignaci�n de propiedades y restricciones de la ruta */
        if (id && ido) {
            strcpy(vector_conexiones[c].id_conexion, id);
            vector_conexiones[c].id_origen = atoi(ido);
            strcpy(vector_conexiones[c].nombre_origen, nomo);
            vector_conexiones[c].id_destino = atoi(idd);
            strcpy(vector_conexiones[c].nombre_destino, nomd);
            strcpy(vector_conexiones[c].estado, est);
            strcpy(vector_conexiones[c].objeto_necesario, obj);
            c++;
        }
    }
    fclose(f);
    return c;
}

/**
 * @brief Recupera la informaci�n de todos los objetos interactuables y su posicionamiento.
 * @pre El archivo "Objetos.txt" debe cumplir con el formato t�cnico de campos delimitados.
 * @post Retorna la cantidad de objetos cargados satisfactoriamente en el vector_objetos.
 */
int cargar_objetos(Objeto vector_objetos[]) {
    /* Acceso al registro f�sico de elementos interactuables */
    FILE *f = fopen("Objetos.txt", "r");
    if (!f) return 0;

    char linea[600];
    int c = 0;

    /* Lectura estructurada de las entidades f�sicas del juego */
    while (fgets(linea, sizeof(linea), f) && c < MAX_OBJETOS) {

        /* Descomposici�n de la cadena de texto en tokens */
        char *id = strtok(linea, "-");
        char *nom = strtok(NULL, "-");
        char *des = strtok(NULL, "-");
        char *loc = strtok(NULL, "\n\r");

        /* Poblaci�n de la estructura del objeto con sus metadatos espaciales */
        if (id && nom) {
            strcpy(vector_objetos[c].id_obj, id);
            strcpy(vector_objetos[c].nombre, nom);
            strcpy(vector_objetos[c].descripcion, des);
            strcpy(vector_objetos[c].localizacion, loc);
            c++;
        }
    }
    fclose(f);
    return c;
}

/**
 * @brief Extrae la definici�n de los desaf�os l�gicos y sus soluciones.
 * @pre El archivo "Puzles.txt" debe ser accesible y estar correctamente formateado.
 * @post Asocia los puzles con sus respectivas preguntas y respuestas en el sistema de memoria.
 */
int cargar_puzles(Puzle vector_puzles[]) {
    /* Apertura del manifiesto de pruebas y enigmas l�gicos */
    FILE *f = fopen("Puzles.txt", "r");
    if (!f) return 0;

    char linea[600];
    int c = 0;

    /* Bucle principal de carga de l�gica condicional */
    while (fgets(linea, sizeof(linea), f) && c < MAX_PUZLES) {

        /* Parseo de inc�gnitas y resoluci�n de dependencias por sala */
        char *id = strtok(linea, "-");
        char *nom = strtok(NULL, "-");
        strtok(NULL, "-"); // Salto del ID de sala (no requerido por el struct)
        char *tip = strtok(NULL, "-");
        char *pre = strtok(NULL, "-");
        char *sol = strtok(NULL, "\n\r");

        /* Consolidaci�n de datos del puzle en su respectivo vector */
        if (id && nom) {
            strcpy(vector_puzles[c].id_puzle, id);
            strcpy(vector_puzles[c].nombre, nom);
            strcpy(vector_puzles[c].tipo, tip);
            strcpy(vector_puzles[c].pregunta, pre);
            strcpy(vector_puzles[c].solucion, sol);
            c++;
        }
    }
    fclose(f);
    return c;
}

/**
 * @brief Serializa el estado integral de la partida en un soporte f�sico de persistencia.
 * @pre id_jugador debe identificar un usuario registrado; los vectores deben contener el estado actual.
 * @post Genera un archivo "Partida_[ID].txt" con la ubicaci�n y el estado de todas las entidades.
 */
void guardar_partida(char* id_jugador, int id_sala, Objeto v_obj[], int t_obj, Conexion v_con[], int t_con) {
    /* Configuraci�n din�mica del descriptor de archivo para guardado */
    char nombre_fichero[30];
    sprintf(nombre_fichero, "Partida_%s.txt", id_jugador);

    FILE *f = fopen(nombre_fichero, "w");
    if (!f) return;

    /* Registro de metadatos de usuario y posicionamiento jer�rquico */
    fprintf(f, "JUGADOR: %s\n", id_jugador);
    fprintf(f, "SALA: %02d\n", id_sala);

    /* Serializaci�n sistem�tica de la ubicaci�n de los objetos */
    for (int i = 0; i < t_obj; i++)
        fprintf(f, "OBJETO: %s-%s\n", v_obj[i].id_obj, v_obj[i].localizacion);

    /* Serializaci�n sistem�tica del estado din�mico de las conexiones */
    for (int i = 0; i < t_con; i++)
        fprintf(f, "CONEXION: %s-%s\n", v_con[i].id_conexion, v_con[i].estado);

    /* Persistencia de estados de puzles resueltos basados en conexiones activas */
    for (int i = 0; i < t_con; i++) {
        if (strcmp(v_con[i].estado, "Activa") == 0 && v_con[i].objeto_necesario[0] == 'P') {
             fprintf(f, "PUZLE: %s-Resuelto\n", v_con[i].objeto_necesario);
        }
    }

    fclose(f);
    printf("\n[SISTEMA] Partida guardada en %s\n", nombre_fichero);
}

/**
 * @brief Restaura el estado de juego desde un archivo de salvaguarda previo.
 * @pre Debe existir un archivo "Partida_[ID].txt" para el jugador indicado.
 * @post Actualiza la sala actual y el estado de objetos/conexiones en memoria. Retorna 1 si tuvo �xito.
 */
int cargar_partida(char* id_jugador, int *id_sala, Objeto v_obj[], int t_obj, Conexion v_con[], int t_con) {
    /* Reconstrucci�n del nombre del archivo de sesi�n */
    char nombre_fichero[30];
    sprintf(nombre_fichero, "Partida_%s.txt", id_jugador);

    FILE *f = fopen(nombre_fichero, "r");
    if (!f) return 0;

    char linea[200];
    /* Bucle de lectura y recreaci�n del estado del mundo */
    while (fgets(linea, sizeof(linea), f)) {
        char *etiqueta = strtok(linea, ": ");
        char *valor = strtok(NULL, "\n\r ");
        if (!etiqueta || !valor) continue;

        /* Procesamiento condicional seg�n la etiqueta de datos */
        if (strcmp(etiqueta, "SALA") == 0) {
            *id_sala = atoi(valor);
        } else if (strcmp(etiqueta, "OBJETO") == 0) {
            /* Sincronizaci�n de ubicaci�n de objetos */
            char *id = strtok(valor, "-");
            char *loc = strtok(NULL, "-");
            for(int i=0; i<t_obj; i++)
                if(strcmp(v_obj[i].id_obj, id) == 0) strcpy(v_obj[i].localizacion, loc);
        } else if (strcmp(etiqueta, "CONEXION") == 0) {
            /* Sincronizaci�n de estados de puertas y accesos */
            char *id = strtok(valor, "-");
            char *est = strtok(NULL, "-");
            for(int i=0; i<t_con; i++)
                if(strcmp(v_con[i].id_conexion, id) == 0) strcpy(v_con[i].estado, est);
        }
    }

    fclose(f);
    return 1;
}
