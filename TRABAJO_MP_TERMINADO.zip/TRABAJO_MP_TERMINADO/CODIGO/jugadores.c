#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "jugadores.h"

/**
 * @brief Actualiza la persistencia del inventario del usuario en el sistema de archivos.
 * @pre La estructura jugador debe contener un ID v�lido y el archivo "Jugadores.txt" debe existir.
 * @post Sobrescribe el registro del jugador en el archivo con la informaci�n de inventario actualizada.
 */
void guardar_inventario_usuario(Jugador jugador) {
    FILE *f = fopen("Jugadores.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    char linea[300];

    if (!f || !temp) return;

    while (fgets(linea, sizeof(linea), f)) {
        char linea_copy[300];
        strcpy(linea_copy, linea);

        char *id = strtok(linea_copy, "-");

        if (id && strcmp(id, jugador.id) == 0) {
            fprintf(temp, "%s-%s-%s-%s-%s\n", jugador.id, jugador.nombre_completo, jugador.login, jugador.password, jugador.inventario);
        } else {
            fputs(linea, temp);
        }
    }

    fclose(f);
    fclose(temp);
    remove("Jugadores.txt");
    rename("temp.txt", "Jugadores.txt");
}

/**
 * @brief Muestra por pantalla la lista de objetos contenidos en el inventario del jugador.
 * @pre El puntero jugador debe ser v�lido; vector_objetos debe estar cargado con los datos del sistema.
 * @post Imprime el nombre e ID de cada objeto pose�do o un mensaje de inventario vac�o.
 */
void mostrar_inventario(Jugador *jugador, Objeto vector_objetos[], int total_objetos) {
    printf("\n--- INVENTARIO ---\n");
    if (strcmp(jugador->inventario, "0") == 0 || strlen(jugador->inventario) == 0) {
        printf("Tu inventario esta vacio.\n");
        return;
    }

    char aux[100];
    strcpy(aux, jugador->inventario);
    char *token = strtok(aux, ",");
    while (token != NULL) {
        for (int i = 0; i < total_objetos; i++) {
            if (strcmp(vector_objetos[i].id_obj, token) == 0) {
                printf("- %s (%s)\n", vector_objetos[i].nombre, vector_objetos[i].id_obj);
            }
        }
        token = strtok(NULL, ",");
    }
}
