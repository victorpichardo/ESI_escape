#ifndef OBJETOS_H
#define OBJETOS_H

#include "salas.h"
#include "usuarios.h"

/**
 * @brief Transfiere un objeto desde la ubicaci�n actual al inventario del jugador.
 * @pre El identificador id_sala debe ser v�lido y el vector de objetos debe estar inicializado.
 * @post Actualiza el campo de localizaci�n del objeto y el inventario del jugador.
 */
void coger_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos);

/**
 * @brief Deposita un objeto del inventario del jugador en la sala actual.
 * @pre El jugador debe poseer el objeto referenciado en su inventario.
 * @post Modifica la localizaci�n del objeto en el vector y actualiza la persistencia del inventario.
 */
void soltar_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos);

/**
 * @brief Aplica la l�gica de uso de un objeto sobre el entorno actual.
 * @pre El jugador debe poseer el objeto seleccionado y estar en una sala compatible con su uso.
 * @post Altera el estado de las conexiones de la sala si el uso del objeto desbloquea un acceso.
 */
void usar_objeto(int id_sala, Jugador *jugador, Objeto vector_objetos[], int total_objetos, Conexion vector_conexiones[], int total_conexiones);

#endif
